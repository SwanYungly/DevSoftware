import java.util.Scanner;

public class App {
    public static void main(String[] args) throws Exception {
        Scanner input =  new Scanner(System.in); // inicia o leitor 
        System.out.println("Digite um número: "); // exibe a mensagem
        int numero =  input.nextInt(); // Lê do teclado
        System.out.println("Você digitou o número: "+numero); // exibe o numero digitado
        System.out.println("Digite outro número: ");
        int numero2 = input.nextInt();
        input.close(); // fecha o leitor
        
    }
}
